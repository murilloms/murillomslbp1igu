from flask import Flask, request, session, redirect, url_for, abort, render_template, Blueprint

logincontroller = Blueprint('logindablueprint ', __name__)

@logincontroller.route('/')
def index():
    return render_template('index.html')

@logincontroller.route('/login')
def logar():
    return render_template('login.html')
