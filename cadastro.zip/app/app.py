from flask import Flask, render_template, request, redirect, flash, url_for, session

nomeCerto = True

app = Flask(__name__)
app.secret_key = "supersecretkey"

cadastro = []
errors = []

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nome = request.form['name']
        email = request.form['email']
        senha = request.form['password']
        confirma = request.form['confirm-password']

        if len(nome) < 3:
            errors.append('O nome deve ter, no mínimo, 3 caracteres','error')
            return redirect('/')
        
        if len(senha) < 8 or len(senha)> 12:
           errors.append('A senha deve ter entre 3 e 12 caracteres','error')
           return redirect('/')
        if senha != confirma:
            errors.append('confirmação de senha incorreta','error')
            return redirect('/')

    return render_template('login.html')


@app.route('/cadastrado',)
def admin_dashboard():
    if 'username' in session:
        return f"Bem-vindo ao painel de admin, {session['username']}!"
    else:
        return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)